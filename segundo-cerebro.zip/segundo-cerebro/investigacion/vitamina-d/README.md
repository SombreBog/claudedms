# Protocolo: Vitamina D sérica en fracturas por trauma de baja energía

## Estado actual
- 

## Pendientes
- [ ] 

## Notas
- [[bibliografia]]
- [[metodologia]]
