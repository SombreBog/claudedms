# Metodología

- **Diseño:** 
- **Población:** 
- **Criterios de inclusión:** 
- **Criterios de exclusión:** 
- **Variables:** 
- **Análisis estadístico:** 
