# Bibliografía — Vitamina D

| Artículo | Año | Hallazgo clave | Nota |
|---|---|---|---|
| | | | [[ ]] |
