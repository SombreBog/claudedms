# Artículos

Una nota por artículo, usando la plantilla [[articulo]].
Nombre sugerido: `año-primer-autor-tema.md` (ej. `2024-smith-fractura-cadera.md`).

## Índice por tema
- **Cadera:** 
- **Rodilla:** 
- **Trauma:** 
- **Columna:** 
