# 🧠 Segundo cerebro — Diego

Índice general. Cada carpeta es un área; cada nota es un archivo `.md`.
Enlaza notas entre sí con `[[nombre-de-la-nota]]`.

| Carpeta | Para qué |
|---|---|
| [00-inbox](00-inbox/) | Ideas rápidas sin ordenar. Vacíala 1 vez por semana. |
| [residencia](residencia/) | Guardias, casos docentes, censo QX, pendientes de la residencia. |
| [investigacion/vitamina-d](investigacion/vitamina-d/) | Protocolo de vitamina D en fracturas por baja energía. |
| [articulos](articulos/) | Resúmenes de artículos de ortopedia. |
| [canal-videos](canal-videos/) | Ideas y guiones para el canal de divulgación. |
| [practica-privada](practica-privada/) | Consultorio: pendientes, ideas, agenda. |
| [cv-cirugia-articular](cv-cirugia-articular/) | Postulación a la alta especialidad. |
| [plantillas](plantillas/) | Copia una plantilla para crear notas nuevas. |

## Reglas
1. **Nunca** guardes datos que identifiquen pacientes (nombre, expediente, CURP, fotos con rostro). Usa iniciales o "Px masculino 67 a".
2. Un tema = una nota. Nombre en minúsculas con guiones: `fractura-cadera-anciano.md`.
3. Si no sabes dónde va algo, va a `00-inbox`.
4. Revisa que el repositorio sea **privado** (Settings → General → Danger Zone → Change visibility).

## Cómo usarlo con Claude
- "Resume mis notas de [[tema]]"
- "¿Qué pendientes tengo en el protocolo de vitamina D?"
- "Convierte este artículo en una nota con la plantilla de artículo"
