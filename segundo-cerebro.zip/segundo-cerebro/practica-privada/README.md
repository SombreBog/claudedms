# Práctica privada (con Renan)

## Objetivos
- Aumentar consulta
- Optimizar atención al paciente
- Organizar agenda

## Pendientes
- [ ] 

## Ideas
- 
