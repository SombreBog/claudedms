# Caso: [diagnóstico] — [fecha]

> Sin datos identificables del paciente.

- **Px:** sexo, edad
- **Mecanismo:** 
- **Diagnóstico / clasificación:** 
- **Tratamiento:** 
- **Evolución:** 

## Perla / lo que aprendí

Relacionado: [[ ]]
