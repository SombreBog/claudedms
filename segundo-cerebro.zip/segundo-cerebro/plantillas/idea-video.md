# Video: [título]

- **Artículo base:** [[ ]]
- **Público:** 
- **Duración objetivo:** 

## Gancho (primeros 5 seg)
## Guion
1. 
2. 
3. 
## Mensaje final
