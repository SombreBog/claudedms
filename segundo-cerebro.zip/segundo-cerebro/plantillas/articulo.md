# [Título del artículo]

- **Autores / año / revista:** 
- **DOI o link:** 
- **Tipo de estudio:** 
- **Nivel de evidencia:** 

## Pregunta
## Métodos (resumen)
## Resultados clave
## Limitaciones
## ¿Qué cambia en mi práctica?
## Idea para video (1 frase para público general)

Relacionado: [[ ]]
