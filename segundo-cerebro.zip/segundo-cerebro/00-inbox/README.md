# Inbox
Apunta aquí cualquier idea rápida. Cada semana muévela a su carpeta o bórrala.

- [ ] 
