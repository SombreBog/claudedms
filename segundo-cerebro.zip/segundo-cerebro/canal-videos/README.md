# Canal de videos de ortopedia

Videos que explican artículos de forma resumida para público general.

## Ideas
- [ ] 

## En producción
- 

## Publicados
| Fecha | Título | Artículo base | Link |
|---|---|---|---|
| | | [[ ]] | |
