# Residencia — Ortopedia, Hospital Gea González

## Pendientes
- [ ] 

## Casos docentes
Usa la plantilla [[caso-clinico]]. Sin datos identificables.

## Relacionado
- [[censo-quirurgico]]
