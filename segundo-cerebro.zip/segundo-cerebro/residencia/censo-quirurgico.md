# Censo quirúrgico

Notas sobre mis cirugías como cirujano / ayudante.

| Fecha | Procedimiento | Rol | Notas |
|---|---|---|---|
| | | | |
